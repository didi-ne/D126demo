#ifndef __EXTI_H
#define __EXTI_H	 
#include "stm32f10x.h"  
  
//�ⲿ�ж�0������
void EXTI15_10_IRQHandler(void);  
  
//��ʼ��
void EXTI_GPIO_Config(void);  
void EXTI_INTERRUPT_Config(void);  
void EXTI_NVIC_Config(void);


void EXTI_EVENT_Config(void);

#endif
